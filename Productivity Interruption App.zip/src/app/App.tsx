import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "motion/react"
import {
  Flame, Zap, ChevronRight, Check, X,
  Home, TrendingUp, Play, Timer,
  Dumbbell, Globe, Brain, Trophy,
  Pause, RotateCcw, PlayCircle,
} from "lucide-react"

type Screen = "interrupt" | "home" | "feed" | "progress" | "timer"
type Category = "workout" | "language" | "brain"

interface Activity {
  id: string
  title: string
  subtitle: string
  desc: string
  xp: number
  time: string
  img: string
  color: string
  category: Category
}

const ACTIVITIES: Record<Category, Activity[]> = {
  workout: [
    {
      id: "w1",
      title: "10 Push-Ups",
      subtitle: "Upper body · 2 min",
      desc: "Drop and give me 10. Chest to floor, core tight, full lockout at the top. This is where it starts.",
      xp: 50,
      time: "2 min",
      img: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=800&fit=crop&auto=format",
      color: "#ff5c35",
      category: "workout",
    },
    {
      id: "w2",
      title: "60-Second Plank",
      subtitle: "Core stability · 1 min",
      desc: "Get in position. Elbows under shoulders. Hold for 60 seconds. No sagging, no excuses.",
      xp: 60,
      time: "1 min",
      img: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=600&h=800&fit=crop&auto=format",
      color: "#ff5c35",
      category: "workout",
    },
    {
      id: "w3",
      title: "20 Jump Squats",
      subtitle: "Leg power · 3 min",
      desc: "Feet shoulder-width. Squat low, explode up. Land soft. Power starts in the legs.",
      xp: 70,
      time: "3 min",
      img: "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=600&h=800&fit=crop&auto=format",
      color: "#ff5c35",
      category: "workout",
    },
    {
      id: "w4",
      title: "Shadow Boxing",
      subtitle: "Full body · 5 min",
      desc: "3 rounds. Jab, cross, hook, uppercut. Move your feet. Stay light. Fight your worst habit.",
      xp: 80,
      time: "5 min",
      img: "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=600&h=800&fit=crop&auto=format",
      color: "#ff5c35",
      category: "workout",
    },
  ],
  language: [
    {
      id: "l1",
      title: "5 Spanish Words",
      subtitle: "Español · 2 min",
      desc: "Hola · Gracias · Por favor · Buenos días · Adiós. Say each one out loud three times.",
      xp: 40,
      time: "2 min",
      img: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&h=800&fit=crop&auto=format",
      color: "#7b61ff",
      category: "language",
    },
    {
      id: "l2",
      title: "5 Japanese Words",
      subtitle: "日本語 · 2 min",
      desc: "Konnichiwa · Arigatou · Sumimasen · Sayonara · Hai. Language is a superpower.",
      xp: 50,
      time: "2 min",
      img: "https://images.unsplash.com/photo-1528360983277-13d401cdc186?w=600&h=800&fit=crop&auto=format",
      color: "#7b61ff",
      category: "language",
    },
    {
      id: "l3",
      title: "French Phrases",
      subtitle: "Français · 2 min",
      desc: "Bonjour · Merci · S'il vous plaît · Excusez-moi · Au revoir. Start sounding like a local.",
      xp: 45,
      time: "2 min",
      img: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=600&h=800&fit=crop&auto=format",
      color: "#7b61ff",
      category: "language",
    },
  ],
  brain: [
    {
      id: "b1",
      title: "Chess Puzzle",
      subtitle: "Tactical thinking · 3 min",
      desc: "White to move, mate in 2. Visualize before you move. Your brain is a muscle — train it.",
      xp: 60,
      time: "3 min",
      img: "https://images.unsplash.com/photo-1529699211952-734e80c4d42b?w=600&h=800&fit=crop&auto=format",
      color: "#c5f135",
      category: "brain",
    },
    {
      id: "b2",
      title: "Memory Challenge",
      subtitle: "Recall · 2 min",
      desc: "Study this list for 30 seconds: apple, bridge, thunder, clock, silver, mirror, river, flame. Then recall all 8.",
      xp: 55,
      time: "2 min",
      img: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=600&h=800&fit=crop&auto=format",
      color: "#c5f135",
      category: "brain",
    },
    {
      id: "b3",
      title: "Mental Math",
      subtitle: "Arithmetic · 2 min",
      desc: "No calculator. 47 × 3 · 128 + 94 · 250 ÷ 5 · 19 × 6 · 385 − 147. Beat the clock.",
      xp: 45,
      time: "2 min",
      img: "https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&h=800&fit=crop&auto=format",
      color: "#c5f135",
      category: "brain",
    },
  ],
}

const CHECKLIST = [
  { id: "room", label: "Is your room cleaned?", icon: "🏠" },
  { id: "study", label: "Did you finish studying?", icon: "📚" },
  { id: "workout", label: "Did you finish your workout?", icon: "💪" },
  { id: "family", label: "Did you spend time with family?", icon: "❤️" },
]

const CAT_META: Record<Category, { label: string; icon: typeof Dumbbell; color: string }> = {
  workout: { label: "Workout", icon: Dumbbell, color: "#ff5c35" },
  language: { label: "Language", icon: Globe, color: "#7b61ff" },
  brain: { label: "Brain", icon: Brain, color: "#c5f135" },
}

const allActivities: Activity[] = [
  ...ACTIVITIES.workout,
  ...ACTIVITIES.language,
  ...ACTIVITIES.brain,
]

// ─── Interrupt Screen ────────────────────────────────────────────────────────

function InterruptScreen({ onEnter }: { onEnter: () => void }) {
  const [checked, setChecked] = useState<Record<string, boolean>>({})

  const toggle = (id: string) => setChecked(p => ({ ...p, [id]: !p[id] }))
  const uncheckedCount = CHECKLIST.filter(c => !checked[c.id]).length

  return (
    <div className="size-full min-h-screen bg-[#0b0b11] flex flex-col items-center justify-center px-5 relative overflow-hidden">
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-[#ff5c35]/8 blur-3xl pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-sm"
      >
        {/* Badge */}
        <div className="flex justify-center mb-5">
          <div className="px-4 py-1.5 rounded-full border border-[#ff5c35]/40 bg-[#ff5c35]/10">
            <span className="text-[#ff5c35] text-xs font-bold tracking-widest uppercase">
              ⏱ 40 min on TikTok right now
            </span>
          </div>
        </div>

        {/* Headline */}
        <h1
          className="text-center text-white leading-none mb-3"
          style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "clamp(3.2rem, 16vw, 5.5rem)", fontWeight: 900, letterSpacing: "-0.01em" }}
        >
          WAIT UP.
        </h1>

        {/* Weekly loss stat */}
        <div className="flex justify-center mb-4">
          <div className="px-5 py-3 rounded-2xl border border-white/10 bg-white/[0.04] text-center">
            <p className="text-[#9494a8] text-xs font-bold uppercase tracking-widest mb-0.5">This week you lost</p>
            <p className="text-white font-black" style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "2rem" }}>
              6h 20min <span className="text-[#ff5c35]">to scrolling</span>
            </p>
          </div>
        </div>

        {/* Emotional line */}
        <p
          className="text-center text-white font-black mb-5 leading-tight px-2"
          style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "clamp(1.1rem, 5vw, 1.4rem)", letterSpacing: "0.01em" }}
        >
          YOUR FUTURE SELF IS BUILT BY{" "}
          <span className="text-[#c5f135]">TODAY'S CHOICES.</span>
        </p>

        <p className="text-center text-[#9494a8] text-sm mb-5">In those 40 minutes you could have:</p>

        {/* Could-have list */}
        <div className="space-y-2 mb-6">
          {[
            { icon: "🥊", text: "Done 4 rounds of shadowboxing" },
            { icon: "💪", text: "Completed 50 push-ups + jump rope" },
            { icon: "👊", text: "Practiced 100 jabs and crosses" },
            { icon: "🔥", text: "Done a full boxing warmup" },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ x: -16, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.08 * i + 0.2 }}
              className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.06]"
            >
              <span className="text-lg">{item.icon}</span>
              <span className="text-white/75 text-sm font-medium">{item.text}</span>
            </motion.div>
          ))}
        </div>

        {/* Check-in */}
        <div className="rounded-2xl border border-white/8 bg-white/[0.03] p-4 mb-5">
          <p className="text-[#9494a8] text-[11px] font-bold uppercase tracking-widest mb-3">
            Quick check-in
          </p>
          <div className="space-y-1.5">
            {CHECKLIST.map(item => (
              <button
                key={item.id}
                onClick={() => toggle(item.id)}
                className="w-full flex items-center gap-3 py-2.5 px-3 rounded-xl transition-colors duration-150"
                style={{ background: checked[item.id] ? "rgba(197,241,53,0.08)" : "transparent" }}
              >
                <div
                  className="w-5 h-5 rounded-md flex items-center justify-center flex-shrink-0 border-2 transition-all duration-150"
                  style={{
                    borderColor: checked[item.id] ? "#c5f135" : "rgba(255,255,255,0.18)",
                    background: checked[item.id] ? "#c5f135" : "transparent",
                  }}
                >
                  {checked[item.id] && <Check size={11} strokeWidth={3} color="#0b0b11" />}
                </div>
                <span
                  className="text-sm text-left transition-colors duration-150"
                  style={{ color: checked[item.id] ? "#c5f135" : "rgba(255,255,255,0.65)" }}
                >
                  {item.icon} {item.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* CTA */}
        {uncheckedCount > 0 ? (
          <div className="space-y-3">
            <p className="text-center text-[#9494a8] text-sm">
              {uncheckedCount} thing{uncheckedCount > 1 ? "s" : ""} left undone.{" "}
              <span className="text-white font-semibold">Let's fix that.</span>
            </p>
            <motion.button
              whileTap={{ scale: 0.97 }}
              onClick={onEnter}
              className="w-full py-4 rounded-2xl font-black flex items-center justify-center gap-2"
              style={{
                fontFamily: "Barlow Condensed, sans-serif",
                background: "linear-gradient(135deg, #ff3d1a 0%, #ff6a00 100%)",
                color: "#fff",
                letterSpacing: "0.02em",
                fontSize: "1.15rem",
                boxShadow: "0 4px 24px rgba(255,61,26,0.5)",
              }}
            >
              START A 10-MINUTE CHALLENGE
              <ChevronRight size={22} strokeWidth={3} />
            </motion.button>
          </div>
        ) : (
          <motion.button
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            whileTap={{ scale: 0.97 }}
            onClick={onEnter}
            className="w-full py-4 rounded-2xl font-black flex items-center justify-center gap-2 border-2 border-[#c5f135] text-[#c5f135]"
            style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "1.15rem" }}
          >
            ✅ YOU'RE CRUSHING IT — START A CHALLENGE
          </motion.button>
        )}
      </motion.div>
    </div>
  )
}

// ─── Activity Detail Overlay ──────────────────────────────────────────────────

function ActivityOverlay({
  activity,
  completed,
  onClose,
  onComplete,
}: {
  activity: Activity
  completed: boolean
  onClose: () => void
  onComplete: () => void
}) {
  const [done, setDone] = useState(false)

  const handleComplete = () => {
    setDone(true)
    onComplete()
    setTimeout(onClose, 1600)
  }

  return (
    <motion.div
      initial={{ y: "100%" }}
      animate={{ y: 0 }}
      exit={{ y: "100%" }}
      transition={{ type: "spring", damping: 26, stiffness: 220 }}
      className="fixed inset-0 z-50 flex flex-col bg-[#0b0b11]"
    >
      {/* Photo */}
      <div className="relative flex-shrink-0" style={{ height: "52vh" }}>
        <img
          src={activity.img}
          alt={activity.title}
          className="w-full h-full object-cover"
          style={{ background: "#1a1a28" }}
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(to bottom, rgba(11,11,17,0.2) 0%, rgba(11,11,17,0.98) 100%)" }}
        />
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-9 h-9 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center border border-white/10"
        >
          <X size={16} color="white" />
        </button>
        <div className="absolute bottom-0 left-0 right-0 px-6 pb-4">
          <div
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-3 border"
            style={{ background: activity.color + "22", color: activity.color, borderColor: activity.color + "44" }}
          >
            <Zap size={10} />
            {activity.xp} XP
          </div>
          <h2
            className="text-white leading-none mb-0.5"
            style={{ fontFamily: "Barlow Condensed, sans-serif", fontWeight: 900, fontSize: "clamp(2.2rem, 10vw, 3.5rem)" }}
          >
            {activity.title}
          </h2>
          <p className="text-white/50 text-sm">{activity.subtitle}</p>
        </div>
      </div>

      {/* Body */}
      <div className="flex-1 px-6 pt-5 pb-8 flex flex-col">
        <p className="text-white/75 text-base leading-relaxed mb-4 flex-1">{activity.desc}</p>
        <div className="flex items-center gap-4 mb-6 text-sm text-[#9494a8]">
          <span className="flex items-center gap-1.5">
            <Timer size={13} />
            {activity.time}
          </span>
          {completed && (
            <span className="flex items-center gap-1.5 text-[#c5f135]">
              <Check size={13} />
              Completed today
            </span>
          )}
        </div>

        <AnimatePresence mode="wait">
          {done ? (
            <motion.div
              key="done"
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-full py-4 rounded-2xl text-center font-black text-xl"
              style={{ fontFamily: "Barlow Condensed, sans-serif", background: "#c5f135", color: "#0b0b11" }}
            >
              +{activity.xp} XP EARNED! 🔥
            </motion.div>
          ) : (
            <motion.button
              key="cta"
              whileTap={{ scale: 0.97 }}
              onClick={handleComplete}
              className="w-full py-4 rounded-2xl font-black text-xl transition-all"
              style={{ fontFamily: "Barlow Condensed, sans-serif", background: "linear-gradient(135deg, #ff3d1a 0%, #ff6a00 100%)", color: "#fff", boxShadow: "0 4px 20px rgba(255,61,26,0.4)" }}
            >
              {completed ? "DO IT AGAIN →" : "MARK COMPLETE →"}
            </motion.button>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  )
}

// ─── Home Screen ──────────────────────────────────────────────────────────────

function HomeScreen({
  completedIds,
  onSelect,
  onStartChallenge,
  replacedMins,
  streak,
}: {
  completedIds: string[]
  onSelect: (a: Activity) => void
  onStartChallenge: (a: Activity) => void
  replacedMins: number
  streak: number
}) {
  const [tab, setTab] = useState<Category>("workout")
  const featured = ACTIVITIES.workout[0]

  return (
    <div className="pb-6">
      {/* Stats row */}
      <div className="mt-4 mb-5 flex gap-3">
        {/* Mins saved */}
        <div
          className="flex-1 px-4 py-3 rounded-2xl flex items-center justify-between relative overflow-hidden"
          style={{ background: "linear-gradient(135deg, #1a2a0a 0%, #0f1a05 100%)", border: "1px solid rgba(197,241,53,0.22)" }}
        >
          <div className="absolute -right-3 -bottom-3 w-16 h-16 rounded-full bg-[#c5f135]/10 blur-xl" />
          <div>
            <p className="text-[#c5f135]/80 text-[10px] font-bold uppercase tracking-widest mb-0.5">Mins saved</p>
            <p className="text-white font-black text-2xl leading-none" style={{ fontFamily: "Barlow Condensed, sans-serif" }}>
              {replacedMins}
            </p>
          </div>
          <Trophy size={22} color="#c5f135" />
        </div>
        {/* Streak */}
        <div
          className="flex-1 px-4 py-3 rounded-2xl flex items-center justify-between relative overflow-hidden"
          style={{ background: "linear-gradient(135deg, #2a1200 0%, #1a0a00 100%)", border: "1px solid rgba(255,92,53,0.28)" }}
        >
          <div className="absolute -right-3 -bottom-3 w-16 h-16 rounded-full bg-[#ff5c35]/15 blur-xl" />
          <div>
            <p className="text-[#ff5c35]/80 text-[10px] font-bold uppercase tracking-widest mb-0.5">Day streak</p>
            <p className="text-white font-black text-2xl leading-none" style={{ fontFamily: "Barlow Condensed, sans-serif" }}>
              {streak}
            </p>
          </div>
          <Flame size={22} color="#ff5c35" />
        </div>
      </div>

      {/* Featured card */}
      <p className="text-[#9494a8] text-[11px] font-bold uppercase tracking-widest mb-3">Today's featured</p>
      <motion.button
        whileTap={{ scale: 0.985 }}
        onClick={() => onSelect(featured)}
        className="w-full rounded-2xl overflow-hidden relative mb-4"
        style={{ height: 240, boxShadow: "0 8px 32px rgba(255,92,53,0.18)" }}
      >
        <img src={featured.img} alt={featured.title} className="w-full h-full object-cover" style={{ background: "#1a1a28" }} />
        {/* Strong bottom-up gradient for text legibility */}
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(11,11,17,1) 0%, rgba(11,11,17,0.55) 50%, rgba(11,11,17,0.05) 100%)" }} />
        {/* Subtle red tint overlay on the left */}
        <div className="absolute inset-0" style={{ background: "linear-gradient(to right, rgba(255,60,20,0.18) 0%, transparent 60%)" }} />
        <div className="absolute inset-0 p-5 flex flex-col justify-end">
          <div
            className="inline-flex self-start items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-bold uppercase tracking-widest mb-2"
            style={{ background: "#ff3d1a", color: "#fff" }}
          >
            <Flame size={10} /> FEATURED
          </div>
          <h3 className="text-white leading-none mb-1" style={{ fontFamily: "Barlow Condensed, sans-serif", fontWeight: 900, fontSize: "2.4rem", textShadow: "0 2px 12px rgba(0,0,0,0.6)" }}>
            {featured.title}
          </h3>
          <p className="text-white/60 text-sm font-medium">{featured.subtitle}</p>
        </div>
        {completedIds.includes(featured.id) && (
          <div className="absolute top-4 right-4 w-7 h-7 rounded-full bg-[#c5f135] flex items-center justify-center" style={{ boxShadow: "0 0 12px rgba(197,241,53,0.6)" }}>
            <Check size={14} color="#0b0b11" strokeWidth={3} />
          </div>
        )}
      </motion.button>

      {/* Start Challenge CTA */}
      <motion.button
        whileTap={{ scale: 0.97 }}
        onClick={() => onStartChallenge(featured)}
        className="w-full py-4 rounded-2xl font-black text-xl flex items-center justify-center gap-2 mb-6"
        style={{
          fontFamily: "Barlow Condensed, sans-serif",
          background: "linear-gradient(135deg, #ff3d1a 0%, #ff6a00 100%)",
          color: "#fff",
          boxShadow: "0 4px 24px rgba(255,61,26,0.45)",
          letterSpacing: "0.02em",
        }}
      >
        <PlayCircle size={22} strokeWidth={2.5} />
        START A 10-MINUTE CHALLENGE
      </motion.button>

      {/* Category tabs */}
      <div className="flex gap-2 mb-4">
        {(Object.keys(CAT_META) as Category[]).map(cat => {
          const meta = CAT_META[cat]
          const Icon = meta.icon
          const active = tab === cat
          return (
            <button
              key={cat}
              onClick={() => setTab(cat)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-sm font-bold transition-all duration-150"
              style={{
                background: active ? meta.color : "rgba(255,255,255,0.05)",
                color: active ? "#0b0b11" : "#9494a8",
                boxShadow: active ? `0 0 16px ${meta.color}55` : "none",
              }}
            >
              <Icon size={13} strokeWidth={active ? 2.5 : 2} />
              {meta.label}
            </button>
          )
        })}
      </div>

      {/* Activity cards */}
      <div className="space-y-3">
        {ACTIVITIES[tab].map((act, i) => (
          <motion.button
            key={act.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelect(act)}
            className="w-full flex items-center gap-0 rounded-2xl text-left overflow-hidden"
            style={{ background: "#1e1e2e", border: "1px solid rgba(255,255,255,0.09)", boxShadow: "0 2px 12px rgba(0,0,0,0.3)" }}
          >
            {/* Larger thumbnail */}
            <div className="w-24 h-24 flex-shrink-0 relative overflow-hidden" style={{ borderRadius: "16px 0 0 16px" }}>
              <img src={act.img} alt={act.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0" style={{ background: `linear-gradient(to right, transparent 60%, #1e1e2e 100%)` }} />
            </div>
            <div className="flex-1 min-w-0 px-4 py-3">
              <p className="text-white font-black text-base leading-tight mb-0.5" style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "1.15rem" }}>{act.title}</p>
              <p className="text-[#9494a8] text-xs mb-2">{act.subtitle}</p>
              <div className="flex items-center gap-2">
                <span
                  className="flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold"
                  style={{ background: act.color + "22", color: act.color }}
                >
                  <Zap size={9} /> {act.xp} XP
                </span>
                <span className="flex items-center gap-1 text-[11px] text-[#9494a8]">
                  <Timer size={9} /> {act.time}
                </span>
              </div>
            </div>
            <div className="pr-4 flex-shrink-0">
              {completedIds.includes(act.id) ? (
                <div className="w-7 h-7 rounded-full bg-[#c5f135] flex items-center justify-center" style={{ boxShadow: "0 0 10px rgba(197,241,53,0.5)" }}>
                  <Check size={13} color="#0b0b11" strokeWidth={3} />
                </div>
              ) : (
                <div className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.07)" }}>
                  <ChevronRight size={14} color="white" />
                </div>
              )}
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  )
}

// ─── Feed Screen (TikTok-style) ───────────────────────────────────────────────

function FeedScreen({
  completedIds,
  onSelect,
}: {
  completedIds: string[]
  onSelect: (a: Activity) => void
}) {
  const [idx, setIdx] = useState(0)
  const act = allActivities[idx % allActivities.length]

  const go = (dir: 1 | -1) => {
    setIdx(p => (p + dir + allActivities.length) % allActivities.length)
  }

  return (
    <div className="relative" style={{ height: "calc(100vh - 130px)" }}>
      <AnimatePresence mode="wait">
        <motion.div
          key={idx}
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 1.02 }}
          transition={{ duration: 0.22 }}
          className="relative w-full rounded-2xl overflow-hidden cursor-pointer"
          style={{ height: "100%" }}
          onClick={() => onSelect(act)}
        >
          <img
            src={act.img}
            alt={act.title}
            className="w-full h-full object-cover"
            style={{ background: "#1a1a28" }}
          />
          <div
            className="absolute inset-0"
            style={{ background: "linear-gradient(to top, rgba(11,11,17,1) 0%, rgba(11,11,17,0.5) 50%, rgba(11,11,17,0.1) 100%)" }}
          />

          {/* Top tag */}
          <div className="absolute top-4 left-4">
            <div
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest border backdrop-blur-sm"
              style={{ background: act.color + "22", color: act.color, borderColor: act.color + "44" }}
            >
              {act.category === "workout" && <Dumbbell size={10} />}
              {act.category === "language" && <Globe size={10} />}
              {act.category === "brain" && <Brain size={10} />}
              {CAT_META[act.category].label}
            </div>
          </div>

          {/* Counter */}
          <div className="absolute top-4 right-4 px-2.5 py-1 rounded-full bg-black/40 backdrop-blur-sm border border-white/10">
            <span className="text-white/60 text-xs font-bold">{idx + 1} / {allActivities.length}</span>
          </div>

          {/* Bottom content */}
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <div
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border mb-3"
              style={{ background: act.color + "22", color: act.color, borderColor: act.color + "44" }}
            >
              <Zap size={10} /> {act.xp} XP · {act.time}
            </div>
            <h2
              className="text-white leading-none mb-2"
              style={{ fontFamily: "Barlow Condensed, sans-serif", fontWeight: 900, fontSize: "clamp(2.4rem, 11vw, 3.8rem)" }}
            >
              {act.title}
            </h2>
            <p className="text-white/60 text-sm mb-5 line-clamp-2">{act.desc}</p>

            <div className="flex gap-3">
              <button
                onClick={e => { e.stopPropagation(); go(-1) }}
                className="flex-1 py-3 rounded-xl border border-white/15 text-white/70 font-semibold text-sm transition-all active:scale-95"
                style={{ background: "rgba(255,255,255,0.06)" }}
              >
                ← Prev
              </button>
              <button
                onClick={e => { e.stopPropagation(); onSelect(act) }}
                className="flex-[2] py-3 rounded-xl font-black text-base transition-all active:scale-95"
                style={{ fontFamily: "Barlow Condensed, sans-serif", background: act.color, color: "#0b0b11" }}
              >
                {completedIds.includes(act.id) ? "✓ DO AGAIN" : "START NOW"}
              </button>
              <button
                onClick={e => { e.stopPropagation(); go(1) }}
                className="flex-1 py-3 rounded-xl border border-white/15 text-white/70 font-semibold text-sm transition-all active:scale-95"
                style={{ background: "rgba(255,255,255,0.06)" }}
              >
                Next →
              </button>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

// ─── Progress Screen ──────────────────────────────────────────────────────────

function ProgressScreen({
  xp,
  streak,
  completedIds,
  replacedMins,
}: {
  xp: number
  streak: number
  completedIds: string[]
  replacedMins: number
}) {
  const level = Math.floor(xp / 500) + 1
  const xpInLevel = xp % 500
  const xpProgress = (xpInLevel / 500) * 100

  const byCategory: Record<Category, number> = { workout: 0, language: 0, brain: 0 }
  completedIds.forEach(id => {
    const act = allActivities.find(a => a.id === id)
    if (act) byCategory[act.category]++
  })

  const stats = [
    { label: "Total XP", value: xp.toLocaleString(), color: "#c5f135" },
    { label: "Day Streak", value: `${streak}🔥`, color: "#ff5c35" },
    { label: "Completed", value: completedIds.length.toString(), color: "#7b61ff" },
    { label: "Mins Saved", value: replacedMins.toString(), color: "#38d9f5" },
  ]

  return (
    <div className="pb-8 pt-2">
      {/* Level card */}
      <div
        className="rounded-2xl p-5 mb-5 border relative overflow-hidden"
        style={{ background: "#17172a", borderColor: "rgba(197,241,53,0.2)" }}
      >
        <div className="absolute -right-6 -top-6 w-32 h-32 rounded-full bg-[#c5f135]/5 blur-2xl" />
        <div className="flex items-end justify-between mb-3">
          <div>
            <p className="text-[#9494a8] text-xs font-bold uppercase tracking-widest">Current level</p>
            <p
              className="text-white leading-none"
              style={{ fontFamily: "Barlow Condensed, sans-serif", fontWeight: 900, fontSize: "3.5rem" }}
            >
              LVL {level}
            </p>
          </div>
          <p className="text-[#c5f135] text-sm font-bold">{xpInLevel} / 500 XP</p>
        </div>
        <div className="w-full h-2 rounded-full bg-white/10">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${xpProgress}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="h-full rounded-full"
            style={{ background: "#c5f135" }}
          />
        </div>
        <p className="text-[#9494a8] text-xs mt-2">{500 - xpInLevel} XP to level {level + 1}</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-3 mb-5">
        {stats.map(stat => (
          <div
            key={stat.label}
            className="rounded-2xl p-4 border"
            style={{ background: "#17172a", borderColor: "rgba(255,255,255,0.07)" }}
          >
            <p className="text-[#9494a8] text-xs font-bold uppercase tracking-widest mb-1">{stat.label}</p>
            <p
              className="font-black leading-none"
              style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "2rem", color: stat.color }}
            >
              {stat.value}
            </p>
          </div>
        ))}
      </div>

      {/* By category */}
      <p className="text-[#9494a8] text-xs font-bold uppercase tracking-widest mb-3">By category</p>
      <div className="space-y-3">
        {(Object.keys(CAT_META) as Category[]).map(cat => {
          const meta = CAT_META[cat]
          const Icon = meta.icon
          const count = byCategory[cat]
          const total = ACTIVITIES[cat].length
          const pct = total > 0 ? (count / total) * 100 : 0
          return (
            <div
              key={cat}
              className="rounded-2xl p-4 border"
              style={{ background: "#17172a", borderColor: "rgba(255,255,255,0.07)" }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Icon size={15} color={meta.color} />
                  <span className="text-white font-semibold text-sm">{meta.label}</span>
                </div>
                <span className="text-[#9494a8] text-xs">{count}/{total} done</span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-white/10">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${pct}%` }}
                  transition={{ duration: 0.7, ease: "easeOut" }}
                  className="h-full rounded-full"
                  style={{ background: meta.color }}
                />
              </div>
            </div>
          )
        })}
      </div>

      {/* Streak calendar */}
      <p className="text-[#9494a8] text-xs font-bold uppercase tracking-widest mt-5 mb-3">This week</p>
      <div
        className="rounded-2xl p-4 border flex items-center justify-between"
        style={{ background: "#17172a", borderColor: "rgba(255,255,255,0.07)" }}
      >
        {["M", "T", "W", "T", "F", "S", "S"].map((day, i) => {
          const active = i < streak % 7
          return (
            <div key={i} className="flex flex-col items-center gap-1.5">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center"
                style={{ background: active ? "#ff5c35" : "rgba(255,255,255,0.06)" }}
              >
                {active ? <Flame size={16} color="white" /> : <span className="text-[#9494a8] text-xs font-bold">{day}</span>}
              </div>
              <span className="text-[9px] font-bold" style={{ color: active ? "#ff5c35" : "#9494a8" }}>{day}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ─── Workout configs ──────────────────────────────────────────────────────────

type WorkoutMode = "amrap" | "hold" | "rounds"

interface WorkoutCfg {
  mode: WorkoutMode
  workSecs: number
  restSecs?: number
  totalRounds?: number
  instruction: string
}

const WORKOUT_CFG: Record<string, WorkoutCfg> = {
  w1: { mode: "amrap",  workSecs: 60,  instruction: "Go! Do as many push-ups as possible in 60 seconds." },
  w2: { mode: "hold",   workSecs: 60,  instruction: "Hold the plank. Elbows under shoulders. Don't drop." },
  w3: { mode: "amrap",  workSecs: 60,  instruction: "Go! Do as many jump squats as possible in 60 seconds." },
  w4: { mode: "rounds", workSecs: 180, restSecs: 60, totalRounds: 3, instruction: "Shadow box each round. Stay light on your feet." },
}

function getPB(id: string): number | null {
  try {
    const v = localStorage.getItem(`rift_pb_${id}`)
    return v !== null ? parseInt(v) : null
  } catch { return null }
}

function savePB(id: string, score: number): boolean {
  try {
    const current = getPB(id)
    if (current === null || score > current) {
      localStorage.setItem(`rift_pb_${id}`, String(score))
      return true
    }
    return false
  } catch { return false }
}

// ─── Ring Timer ───────────────────────────────────────────────────────────────

function RingTimer({ timeLeft, total, color, running }: { timeLeft: number; total: number; color: string; running: boolean }) {
  const radius = 108
  const circumference = 2 * Math.PI * radius
  const progress = Math.max(0, (total - timeLeft) / total)
  const dashOffset = circumference - progress * circumference
  const mins = String(Math.floor(timeLeft / 60)).padStart(2, "0")
  const secs = String(timeLeft % 60).padStart(2, "0")

  return (
    <div className="relative flex items-center justify-center" style={{ width: 256, height: 256 }}>
      <svg width="256" height="256" className="absolute inset-0 -rotate-90">
        <circle cx="128" cy="128" r={radius} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="10" />
        <circle
          cx="128" cy="128" r={radius}
          fill="none" stroke={color} strokeWidth="10" strokeLinecap="round"
          strokeDasharray={circumference} strokeDashoffset={dashOffset}
          style={{ transition: "stroke-dashoffset 0.95s linear, stroke 0.35s ease" }}
        />
      </svg>
      <div className="flex flex-col items-center justify-center">
        <p
          className="font-black leading-none"
          style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "4.2rem", color: running ? color : "white", transition: "color 0.3s" }}
        >
          {mins}:{secs}
        </p>
      </div>
    </div>
  )
}

// ─── Timer Screen ─────────────────────────────────────────────────────────────

type TimerStage = "preview" | "running" | "input" | "done"

function TimerScreen({
  activity,
  streak,
  onDone,
  onBack,
}: {
  activity: Activity
  streak: number
  onDone: () => void
  onBack: () => void
}) {
  const cfg = WORKOUT_CFG[activity.id] ?? { mode: "hold" as WorkoutMode, workSecs: 60, instruction: activity.desc }

  const [stage, setStage] = useState<TimerStage>("preview")
  const [phase, setPhase] = useState<"work" | "rest">("work")
  const [timeLeft, setTimeLeft] = useState(cfg.workSecs)
  const [running, setRunning] = useState(false)
  const [round, setRound] = useState(1)
  const [repsInput, setRepsInput] = useState("")
  const [savedScore, setSavedScore] = useState<number | null>(null)
  const [isNewPB, setIsNewPB] = useState(false)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const pb = getPB(activity.id)
  const phaseColor = phase === "work" ? "#ff5c35" : "#38d9f5"
  const totalForPhase = phase === "work" ? cfg.workSecs : (cfg.restSecs ?? 60)

  // Start the interval when running
  useEffect(() => {
    if (!running) {
      if (intervalRef.current) clearInterval(intervalRef.current)
      return
    }
    intervalRef.current = setInterval(() => {
      setTimeLeft(t => {
        if (t > 1) return t - 1

        // Timer hit zero
        clearInterval(intervalRef.current!)
        setRunning(false)

        if (cfg.mode === "amrap") {
          setStage("input")
          return 0
        }

        if (cfg.mode === "hold") {
          setStage("done")
          return 0
        }

        // rounds mode
        if (phase === "work") {
          setPhase("rest")
          setRunning(true)
          return cfg.restSecs ?? 60
        } else {
          const nextRound = round + 1
          if (nextRound > (cfg.totalRounds ?? 3)) {
            setStage("done")
            return 0
          }
          setRound(nextRound)
          setPhase("work")
          setRunning(true)
          return cfg.workSecs
        }
      })
    }, 1000)
    return () => { if (intervalRef.current) clearInterval(intervalRef.current) }
  }, [running, phase, round, cfg])

  const startTimer = () => {
    setStage("running")
    setRunning(true)
  }

  const togglePause = () => setRunning(r => !r)

  const reset = () => {
    setRunning(false)
    setStage("preview")
    setPhase("work")
    setTimeLeft(cfg.workSecs)
    setRound(1)
    setRepsInput("")
  }

  const submitReps = () => {
    const reps = parseInt(repsInput)
    if (!reps || reps <= 0) return
    setSavedScore(reps)
    const newRecord = savePB(activity.id, reps)
    setIsNewPB(newRecord)
    setStage("done")
  }

  const handleMarkDone = () => {
    onDone()
  }

  // ── Preview ──
  if (stage === "preview") {
    return (
      <div className="bg-[#0b0b11] flex flex-col px-5 pt-5 pb-8" style={{ minHeight: "100dvh" }}>
        <div className="flex items-center gap-3 mb-6">
          <button onClick={onBack} className="w-9 h-9 rounded-xl bg-white/[0.06] border border-white/10 flex items-center justify-center">
            <X size={16} color="white" />
          </button>
          <div className="flex-1">
            <p className="text-[#9494a8] text-xs font-bold uppercase tracking-widest">
              {cfg.mode === "amrap" ? "AMRAP · 60 sec" : cfg.mode === "rounds" ? `${cfg.totalRounds ?? 3} Rounds` : "Hold"}
            </p>
            <p className="text-white font-bold text-base leading-tight">{activity.title}</p>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#ff5c35]/25 bg-[#ff5c35]/10">
            <Flame size={13} color="#ff5c35" />
            <span className="text-[#ff5c35] font-bold text-sm">{streak}</span>
          </div>
        </div>

        <div className="relative w-full rounded-2xl overflow-hidden mb-5" style={{ height: 220 }}>
          <img src={activity.img} alt={activity.title} className="w-full h-full object-cover" style={{ background: "#1a1a28" }} />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(11,11,17,0.95) 0%, transparent 60%)" }} />
          <div className="absolute bottom-4 left-4 right-4">
            <p className="text-white font-black text-3xl leading-none" style={{ fontFamily: "Barlow Condensed, sans-serif" }}>{activity.title}</p>
            <p className="text-white/50 text-sm">{activity.subtitle}</p>
          </div>
        </div>

        {pb !== null ? (
          <div className="px-4 py-3 rounded-xl border border-[#c5f135]/25 bg-[#c5f135]/8 mb-4">
            <p className="text-[#c5f135] text-xs font-bold uppercase tracking-widest mb-0.5">Personal best</p>
            <p className="text-white font-black text-xl" style={{ fontFamily: "Barlow Condensed, sans-serif" }}>
              {cfg.mode === "amrap" ? `${pb} reps` : `${pb} completions`}
              <span className="text-[#c5f135] text-base font-bold ml-2">— beat it today</span>
            </p>
          </div>
        ) : (
          <div className="px-4 py-3 rounded-xl border border-white/8 bg-white/[0.03] mb-4">
            <p className="text-[#9494a8] text-sm">No personal best yet. Set your first record today.</p>
          </div>
        )}

        <p className="text-[#9494a8] text-sm leading-relaxed mb-6 px-1">{cfg.instruction}</p>

        <div className="flex gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl border border-white/8 bg-white/[0.03]">
            <Zap size={14} color="#c5f135" />
            <span className="text-[#c5f135] font-bold text-sm">{activity.xp} XP</span>
          </div>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={startTimer}
            className="flex-1 py-3 rounded-xl font-black text-lg flex items-center justify-center gap-2"
            style={{ fontFamily: "Barlow Condensed, sans-serif", background: "linear-gradient(135deg, #ff3d1a 0%, #ff6a00 100%)", color: "#fff", boxShadow: "0 4px 20px rgba(255,61,26,0.5)" }}
          >
            <PlayCircle size={20} strokeWidth={2.5} />
            START
          </motion.button>
        </div>
      </div>
    )
  }

  // ── Running ──
  if (stage === "running") {
    const modeLabel = cfg.mode === "amrap"
      ? "AMRAP — max reps!"
      : cfg.mode === "rounds"
        ? phase === "work" ? "🥊 Work" : "💨 Rest"
        : "Hold position!"

    return (
      <div className="bg-[#0b0b11] flex flex-col px-5 pt-5 pb-8 items-center" style={{ minHeight: "100dvh" }}>
        <div className="w-full flex items-center gap-3 mb-6">
          <button onClick={reset} className="w-9 h-9 rounded-xl bg-white/[0.06] border border-white/10 flex items-center justify-center">
            <X size={16} color="white" />
          </button>
          <div className="flex-1">
            <p className="text-white font-bold text-base">{activity.title}</p>
          </div>
          {cfg.mode === "rounds" && (
            <div className="px-3 py-1.5 rounded-full border border-white/10 bg-white/[0.04] text-white/50 font-bold text-xs uppercase tracking-widest">
              R{round}/{cfg.totalRounds ?? 3}
            </div>
          )}
        </div>

        <div
          className="px-5 py-2 rounded-full border font-bold text-sm uppercase tracking-widest mb-8"
          style={{ background: phaseColor + "18", color: phaseColor, borderColor: phaseColor + "44" }}
        >
          {modeLabel}
        </div>

        <RingTimer timeLeft={timeLeft} total={totalForPhase} color={phaseColor} running={running} />

        <p className="text-[#9494a8] text-sm text-center mt-4 mb-10 px-4">{cfg.instruction}</p>

        <div className="flex items-center gap-4">
          <motion.button whileTap={{ scale: 0.92 }} onClick={reset}
            className="w-14 h-14 rounded-2xl flex items-center justify-center border border-white/10 bg-white/[0.05]">
            <RotateCcw size={20} color="#9494a8" />
          </motion.button>
          <motion.button whileTap={{ scale: 0.94 }} onClick={togglePause}
            className="w-20 h-20 rounded-2xl flex items-center justify-center"
            style={{ background: phaseColor, boxShadow: `0 0 32px ${phaseColor}44` }}>
            {running
              ? <Pause size={30} color="#0b0b11" strokeWidth={2.5} />
              : <PlayCircle size={30} color="#0b0b11" strokeWidth={2.5} />
            }
          </motion.button>
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center border border-white/10 bg-white/[0.05]">
            <Timer size={18} color="#9494a8" />
          </div>
        </div>
      </div>
    )
  }

  // ── Reps Input (AMRAP only) ──
  if (stage === "input") {
    return (
      <div className="bg-[#0b0b11] flex flex-col px-5 pt-5 pb-8 items-center justify-center" style={{ minHeight: "100dvh" }}>
        <div className="w-full max-w-sm">
          <p className="text-[#ff5c35] text-xs font-bold uppercase tracking-widest text-center mb-2">Time's up!</p>
          <h2
            className="text-white text-center leading-none mb-2"
            style={{ fontFamily: "Barlow Condensed, sans-serif", fontWeight: 900, fontSize: "3rem" }}
          >
            How many {activity.id === "w1" ? "push-ups" : "jump squats"}?
          </h2>
          {pb !== null && (
            <p className="text-[#9494a8] text-sm text-center mb-6">
              Last time: <span className="text-white font-semibold">{pb} reps</span>. Beat it!
            </p>
          )}
          {pb === null && <p className="text-[#9494a8] text-sm text-center mb-6">Enter your reps below.</p>}
          <input
            type="number"
            inputMode="numeric"
            placeholder="0"
            value={repsInput}
            onChange={e => setRepsInput(e.target.value)}
            className="w-full text-center font-black text-6xl bg-transparent text-white border-b-2 border-[#ff5c35] outline-none mb-8 py-2"
            style={{ fontFamily: "Barlow Condensed, sans-serif" }}
            autoFocus
          />
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={submitReps}
            disabled={!repsInput || parseInt(repsInput) <= 0}
            className="w-full py-4 rounded-2xl font-black text-xl flex items-center justify-center gap-2 transition-opacity"
            style={{
              fontFamily: "Barlow Condensed, sans-serif",
              background: "#c5f135",
              color: "#0b0b11",
              opacity: repsInput && parseInt(repsInput) > 0 ? 1 : 0.4,
            }}
          >
            SAVE MY SCORE →
          </motion.button>
        </div>
      </div>
    )
  }

  // ── Done ──
  return (
    <div className="bg-[#0b0b11] flex flex-col px-5 pt-5 pb-8 items-center justify-center" style={{ minHeight: "100dvh" }}>
      <div className="w-full max-w-sm text-center">
        <motion.div initial={{ scale: 0.7, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", damping: 14 }}>
          <p className="text-6xl mb-4">🔥</p>
          <h2
            className="text-white leading-none mb-3"
            style={{ fontFamily: "Barlow Condensed, sans-serif", fontWeight: 900, fontSize: "3rem" }}
          >
            WORKOUT DONE
          </h2>

          {savedScore !== null && (
            <div className="px-5 py-4 rounded-2xl border mb-4" style={{
              background: isNewPB ? "rgba(197,241,53,0.1)" : "rgba(255,255,255,0.04)",
              borderColor: isNewPB ? "rgba(197,241,53,0.3)" : "rgba(255,255,255,0.08)",
            }}>
              <p className="text-[#9494a8] text-xs font-bold uppercase tracking-widest mb-1">
                {isNewPB ? "🏆 New personal best!" : "Your score"}
              </p>
              <p className="font-black text-4xl" style={{ fontFamily: "Barlow Condensed, sans-serif", color: isNewPB ? "#c5f135" : "white" }}>
                {savedScore} reps
              </p>
              {!isNewPB && pb !== null && (
                <p className="text-[#9494a8] text-sm mt-1">Best: {pb} reps — keep pushing</p>
              )}
            </div>
          )}

          {savedScore === null && (
            <div className="px-5 py-4 rounded-2xl border border-[#c5f135]/25 bg-[#c5f135]/8 mb-4">
              <p className="text-[#c5f135] text-xs font-bold uppercase tracking-widest mb-1">Completed</p>
              <p className="text-white font-black text-2xl" style={{ fontFamily: "Barlow Condensed, sans-serif" }}>{activity.title}</p>
            </div>
          )}

          <div className="flex items-center justify-center gap-4 mb-8">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#c5f135]/25 bg-[#c5f135]/8">
              <Zap size={13} color="#c5f135" />
              <span className="text-[#c5f135] font-bold text-sm">+{activity.xp} XP</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#ff5c35]/25 bg-[#ff5c35]/10">
              <Flame size={13} color="#ff5c35" />
              <span className="text-[#ff5c35] font-bold text-sm">Streak +1</span>
            </div>
          </div>
        </motion.div>

        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={handleMarkDone}
          className="w-full py-4 rounded-2xl font-black text-xl flex items-center justify-center gap-2"
          style={{ fontFamily: "Barlow Condensed, sans-serif", background: "linear-gradient(135deg, #ff3d1a 0%, #ff6a00 100%)", color: "#fff", boxShadow: "0 4px 24px rgba(255,61,26,0.45)" }}
        >
          <Check size={22} strokeWidth={3} />
          MARK AS DONE
        </motion.button>
      </div>
    </div>
  )
}

// ─── Root App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("interrupt")
  const [xp, setXp] = useState(1240)
  const [streak, setStreak] = useState(7)
  const [completedIds, setCompletedIds] = useState<string[]>([])
  const [activeActivity, setActiveActivity] = useState<Activity | null>(null)
  const [timerActivity, setTimerActivity] = useState<Activity | null>(null)

  const replacedMins = completedIds.length * 3

  const handleComplete = () => {
    if (activeActivity && !completedIds.includes(activeActivity.id)) {
      setXp(p => p + activeActivity.xp)
      setCompletedIds(p => [...p, activeActivity.id])
    }
  }

  const openActivity = (act: Activity) => {
    if (act.category === "workout") {
      setTimerActivity(act)
      setScreen("timer")
    } else {
      setActiveActivity(act)
    }
  }

  if (screen === "interrupt") {
    return <InterruptScreen onEnter={() => setScreen("home")} />
  }

  if (screen === "timer" && timerActivity) {
    return (
      <TimerScreen
        activity={timerActivity}
        streak={streak}
        onBack={() => setScreen("home")}
        onDone={() => {
          setStreak(s => s + 1)
          if (!completedIds.includes(timerActivity.id)) {
            setXp(p => p + timerActivity.xp)
            setCompletedIds(p => [...p, timerActivity.id])
          }
          setScreen("home")
        }}
      />
    )
  }

  const NAV = [
    { id: "home" as Screen, icon: Home, label: "Home" },
    { id: "feed" as Screen, icon: Play, label: "Challenges" },
    { id: "progress" as Screen, icon: TrendingUp, label: "Progress" },
  ]

  return (
    <div
      className="bg-[#0b0b11] flex flex-col"
      style={{ fontFamily: "Barlow, sans-serif", maxWidth: 480, margin: "0 auto", height: "100dvh", overflow: "hidden" }}
    >
      {/* Activity overlay */}
      <AnimatePresence>
        {activeActivity && (
          <ActivityOverlay
            activity={activeActivity}
            completed={completedIds.includes(activeActivity.id)}
            onClose={() => setActiveActivity(null)}
            onComplete={handleComplete}
          />
        )}
      </AnimatePresence>

      {/* Top bar */}
      <div className="flex items-center justify-between px-5 pt-5 pb-1 flex-shrink-0">
        <div className="flex items-center gap-2">
          {/* Streak pill with glow */}
          <div
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full"
            style={{
              background: "linear-gradient(135deg, rgba(255,61,26,0.25) 0%, rgba(255,106,0,0.15) 100%)",
              border: "1px solid rgba(255,92,53,0.4)",
              boxShadow: "0 0 14px rgba(255,61,26,0.3), inset 0 1px 0 rgba(255,255,255,0.08)",
            }}
          >
            <Flame size={13} color="#ff5c35" />
            <span className="text-white font-black text-sm" style={{ textShadow: "0 0 8px rgba(255,92,53,0.8)" }}>{streak}</span>
          </div>
          {/* XP pill with glow */}
          <div
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full"
            style={{
              background: "linear-gradient(135deg, rgba(197,241,53,0.18) 0%, rgba(197,241,53,0.08) 100%)",
              border: "1px solid rgba(197,241,53,0.35)",
              boxShadow: "0 0 14px rgba(197,241,53,0.2), inset 0 1px 0 rgba(255,255,255,0.06)",
            }}
          >
            <Zap size={13} color="#c5f135" />
            <span className="text-white font-black text-sm" style={{ textShadow: "0 0 8px rgba(197,241,53,0.7)" }}>{xp.toLocaleString()}</span>
          </div>
        </div>
        <p className="font-black text-white tracking-widest" style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "1.2rem", letterSpacing: "0.12em" }}>RIFT</p>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-y-auto px-5" style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch", overscrollBehavior: "contain" }}>
        <AnimatePresence mode="wait">
          <motion.div
            key={screen}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.18 }}
          >
            {screen === "home" && (
              <HomeScreen
                completedIds={completedIds}
                onSelect={openActivity}
                onStartChallenge={openActivity}
                replacedMins={replacedMins}
                streak={streak}
              />
            )}
            {screen === "feed" && (
              <FeedScreen
                completedIds={completedIds}
                onSelect={openActivity}
              />
            )}
            {screen === "progress" && (
              <ProgressScreen
                xp={xp}
                streak={streak}
                completedIds={completedIds}
                replacedMins={replacedMins}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom nav */}
      <div
        className="flex items-center justify-around px-6 py-3 flex-shrink-0"
        style={{ borderTop: "1px solid rgba(255,255,255,0.07)", background: "linear-gradient(to top, #0d0d15 0%, #0b0b11 100%)" }}
      >
        {NAV.map(({ id, icon: Icon, label }) => {
          const active = screen === id
          return (
            <button
              key={id}
              onClick={() => setScreen(id)}
              className="flex flex-col items-center gap-1 transition-all duration-150 relative"
            >
              {active && (
                <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-6 h-0.5 rounded-full bg-[#c5f135]" style={{ boxShadow: "0 0 8px rgba(197,241,53,0.8)" }} />
              )}
              <Icon size={20} strokeWidth={active ? 2.5 : 1.8} color={active ? "#c5f135" : "rgba(255,255,255,0.28)"} />
              <span className="text-[11px] font-bold" style={{ color: active ? "#c5f135" : "rgba(255,255,255,0.28)" }}>{label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
